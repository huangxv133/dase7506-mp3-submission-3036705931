# MP3 SQL Repair Agent report

## Agent loop

A fresh CPU-only agent is created for each task. It executes the original SQL first, requests the fixed repair hints, deduplicates the proposed SQL candidates, and checks each candidate against the public example. It submits the first candidate whose tool feedback matches the example. If none matches within the budget, it submits the first hint candidate or the original draft.

The controller uses the official tool protocol and records the full causal trace. It does not read grading references or evaluation databases during prediction.

## Context and memory

The per-task observation history is the controller context. The supplied fixed repair-hint cache is the only persistent memory used by the final agent. Candidate SQL is generated from the hint cache and the original draft. The agent uses no online model and no external service.

## Results

On the 120-task validation split, the final controller obtained 83 correct tasks, or 69.17%. On the 240-task public test split, it obtained 162 correct tasks, or 67.50%. The complete test prediction document and test-score JSON are included in this export. The test result is self-evaluated and subject to instructor replay and compliance checks.

## Controlled ablations

| Variant | Validation correct | Accuracy |
|---|---:|---:|
| Direct original-draft submission | 47/120 | 39.17% |
| Repair hints with public-example checks | 83/120 | 69.17% |
| Repair hints plus retrieval fallback | 83/120 | 69.17% |

The main gain comes from executing and checking repaired candidates. The retrieval fallback was tested and removed from the final controller because it did not improve validation accuracy and its tool output ordering was less reproducible across local processes.

## Runtime and cost

The final controller uses no live LLM, no model weights, no API calls and no GPU. It uses at most eight charged tool calls per task and one free submit action. The export is intended for the official single-worker reproduction command.

## Failure cases and safeguards

Some fixed hints match the single public example but fail on one or more grading database instances. Other hints have invalid columns or incomplete joins. When all candidates fail the public example, the agent submits the first available candidate within the budget.

Task questions, SQL text and tool feedback are treated as untrusted strings or structured observations. The controller does not execute Python from observations, follow instructions embedded in task text, access arbitrary files or call external services. SQL is executed only through the official read-only tool.

## Provenance and external assistance

The implementation was developed against the official starter package. The benchmark, public data, fixed hints and tool semantics come from that package. No test labels, grading fingerprints or hidden solutions were embedded in the agent. No external model is used during grading.

## Reproduction

Use the commands in `README.md` from the official package root. Keep the official package data and scorer unchanged. The source export contains the implementation, configuration, report, complete test predictions and complete test-score JSON.
