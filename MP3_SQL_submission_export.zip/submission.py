"""Deterministic CPU-only SQL repair controller."""
from collections import OrderedDict

class RepairAgent:
    def __init__(self):
        self.candidates=[]; self.next_candidate=0
    @staticmethod
    def _hint(history):
        for event in reversed(history):
            if event.get('tool')=='repair_hint': return event.get('observation')
        return None
    def act(self, observation):
        history=observation.get('history',[]); original=observation['issue_sql']
        if not history: return {'tool':'execute','sql':original}
        hint=self._hint(history)
        if hint is None: return {'tool':'repair_hint'}
        if not self.candidates:
            unique=OrderedDict()
            for sql in (hint if isinstance(hint,list) else [])+[original]:
                if isinstance(sql,str) and sql.strip(): unique.setdefault(sql.strip(),None)
            self.candidates=list(unique)
        for event in reversed(history):
            if event.get('tool')=='check' and event.get('observation',{}).get('matches_example'):
                return {'tool':'submit','sql':event['sql']}
        checked={event.get('sql') for event in history if event.get('tool')=='check'}
        while self.next_candidate<len(self.candidates):
            sql=self.candidates[self.next_candidate]; self.next_candidate+=1
            if sql not in checked and observation.get('remaining',0)>0: return {'tool':'check','sql':sql}
        return {'tool':'submit','sql':self.candidates[0] if self.candidates else original}

def create_agent(checkpoint=None):
    if checkpoint is not None: raise ValueError('This CPU controller does not use a checkpoint')
    return RepairAgent()
