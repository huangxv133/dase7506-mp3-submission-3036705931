# MP3 SQL Repair Agent submission

This export contains the CPU-only agent, the complete test prediction document, and the complete test-score JSON.

## Reproduction

From the extracted official package root, install `requirements.txt`, then run:

```bash
PYTHONPATH="$PWD/submission_export" python -m mp3_sql.predict --split validation --method submission_export/submission.py --workers 1 --output outputs/validation.json
python -m mp3_sql.score --split validation --predictions outputs/validation.json --workers 1 --output outputs/validation-score.json
PYTHONPATH="$PWD/submission_export" python -m mp3_sql.predict --split test --method submission_export/submission.py --workers 1 --output outputs/test.json
python -m mp3_sql.score --split test --predictions outputs/test.json --workers 1 --output outputs/test-score.json
```

The agent uses the fixed repair hints and public-example checks. It does not use a live LLM or model weights.
